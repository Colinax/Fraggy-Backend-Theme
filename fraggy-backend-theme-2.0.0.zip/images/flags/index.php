<?php
/**
 * Website Baker Theme
 * Additional content to include to the backend
 *
 * Part off: Website Baker theme advanced_theme_wb_flat
 * More information see: info.php in main theme folder
 *
*/

// prevent directory listing
header('Location: ../../../../index.php');

?>