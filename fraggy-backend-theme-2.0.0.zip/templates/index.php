<?php
/**
 * WebsiteBaker template: Fraggy Backend Theme
 * More information see: info.php
 */
if (!defined('WB_PATH')) {
    die(header('Location: ../../index.php'));
}
