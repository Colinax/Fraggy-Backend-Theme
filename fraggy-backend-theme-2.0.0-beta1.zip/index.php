<?php
/**
 * Fraggy Backend Theme
 * Responsive and Bootstrap based backend theme for WBCE
 *
 * @copyright 2016-2017 Jonathan Nessier, Neoflow (https://neoflow.ch)
 * @license MIT
 */
if (!defined('WB_PATH')) {
    die(header('Location: ../../index.php'));
}
